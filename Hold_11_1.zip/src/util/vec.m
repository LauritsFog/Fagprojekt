function X = vec(Z)
    X = Z(:);
end