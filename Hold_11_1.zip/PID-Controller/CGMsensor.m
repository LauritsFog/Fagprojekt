
function y = CGMsensor(x,p)

y = (x(6)-x(7))/p.Tsc;

end